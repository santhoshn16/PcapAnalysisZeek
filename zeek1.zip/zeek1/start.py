import os
import time
from multiprocessing import Process
from multiprocessing import Semaphore
from analysis.createdir import GenerateDir
from analysis.runzeek import RunZeek
import sys

homedir = "/home/santhosh/pythonProject3"
zp = '/home/santhosh/zeek/'
zc1 = '/home/santhosh/zeek/scripts/policy/frameworks/files/extract-all-files.zeek'
zc2 = '/home/santhosh/zeek/scripts/policy/frameworks/files/detect-MHR.zeek'
zc3 = '/home/santhosh/zeek/scripts/policy/protocols/ssh/detect-bruteforcing.zeek'
zc4 = '/home/santhosh/zeek/learn1/tel.zeek'
zc5 = '/home/santhosh/zeek/learn1/credentials.zeek'


def welcome(name):
    print("Network Analysis Started for %s\n" % name)


def bye(name):
    print("Analysis completed for %s\n" % name)


def exec_code(pcap_name):
    gd = GenerateDir(pcap_name)
    gd.makedir()
    rz = RunZeek(pcap_name, zp, zc1, zc2, zc3, zc4, zc5)
    rz.run()
    rz.calculate_metrics()
    # dr = DisplayResults(rz)
    # dr.displayresults()


def exec_code_multi(filename, semaphore):
    time.sleep(5)
    gd = GenerateDir(filename)
    gd.makedir()
    rz = RunZeek(filename, zp, zc1, zc2, zc3, zc4, zc5)
    rz.run()
    rz.calculate_metrics()
    semaphore.release()


if __name__ == "__main__":
    if len(sys.argv) == 1:
        print("please provide directory or pcap file name")
        exit()
    path = sys.argv[1]

    if os.path.isdir(path):
        max_process = 4
        sema = Semaphore(max_process)
        start_time = time.time()
        plist = list()
        for root, dirs, files in os.walk(path, topdown=True):
            for file in files:
                sema.acquire()
                os.system('cp %s %s' % (os.path.join(path, file), homedir))
                print("creating new process")
                t = Process(target=exec_code_multi, args=(file, sema))
                plist.append(t)
                t.start()
        for i in plist:
            i.join()
        print("Time taken ", time.time() - start_time)
        print(plist)

    elif os.path.isfile(path):
        welcome(path)
        exec_code(path)
        bye(path)

    else:
        print("please check entered information")
        exit()
