import os
import subprocess
import json
import re
import pandas as pd
import sys

import matplotlib.pyplot as plt


class RunZeek:
    def __init__(self, pcap_name, zp, zc1, zc2, zc3, zc4, zc5):
        self.pcap = pcap_name
        # provide zeek root folder
        self.zeek_path = zp
        self.zeek_script1 = zc1
        self.zeek_script2 = zc2
        self.zeek_script3 = zc3
        self.zeek_script4 = zc4
        self.zeek_script5 = zc5
        self.result = list()

    def run(self):
        try:
            os.system('zeek -C -r %s %s %s %s %s %s' % (
                self.pcap, self.zeek_script1, self.zeek_script2, self.zeek_script3, self.zeek_script4,
                self.zeek_script5))
        except:
            print("please set zeek path in single.py\n")
            sys.exit(0)

        os.system(
            'cat conn.log|zeek-cut uid id.orig_h id.orig_p id.resp_h id.resp_p proto service duration orig_ip_bytes '
            'resp_ip_bytes orig_pkts resp_pkts |grep tcp >connections.txt')
        os.system("cat connections.txt | awk \'{ print $2\":\"$3}\' > ipsrc.txt")
        os.system("cat connections.txt | awk \'{ print $4\":\"$5}\' > ipdst.txt")
        # os.system("cat connections.txt | awk \'{ print $7}\' > time.txt")
        os.system("cat connections.txt | awk \'{print $1}\' | sort | uniq > uid.txt")

    def calculate_metrics(self):
        defined_service = ['FTP', 'RLOGIN', 'TELNET', 'SSH', 'SMTP']
        with open('connections.txt', 'r') as w:
            data = w.readlines()
            for i in data:
                # we used data1 for creating json format data for each connection
                i = i.rstrip()
                data1 = i.split('\t')
                services = subprocess.check_output("tshark -r %s 'tcp.srcport == %s' | awk '{print $6}' | sort | uniq"
                                                   % (self.pcap, data1[2]), universal_newlines=True, shell=True).split(
                    '\n')
                services = services[:-1]

                for service in services:
                    if service in defined_service:
                        data1.append(str(service))
                        # we have got timestamps and packets
                        timestamps = subprocess.check_output("tshark -r %s 'tcp.srcport == %s and %s' | awk '{print "
                                                             "$2}'" % (self.pcap, data1[2], service.lower()),
                                                             universal_newlines=True, shell=True).split('\n')
                        timestamps = timestamps[:-1]
                        payload_sizes = subprocess.check_output("tshark -r %s 'tcp.srcport == %s and %s' | awk '{print "
                                                                "$7}'" % (self.pcap, data1[2], service.lower()),
                                                                universal_newlines=True, shell=True).split('\n')
                        payload_sizes = payload_sizes[:-1]

                        # calculating T and Alpha
                        tp = len(payload_sizes)
                        tconsecutive = 0
                        aconsecutive = 0
                        sp = 0
                        gp = 0
                        gap = 'F'
                        smp = 'F'
                        for j in range(len(payload_sizes)):
                            if j < len(payload_sizes) - 2:
                                if int(payload_sizes[j + 1]) <= 86 and int(payload_sizes[j]) <= 86:
                                    tconsecutive = tconsecutive + 1
                                    if float(timestamps[j + 1]) - float(timestamps[j]) > 0.01:
                                        if float(timestamps[j + 1]) - float(timestamps[j]) < 2.0:
                                            aconsecutive = aconsecutive + 1

                            if int(payload_sizes[j]) <= 86:
                                sp = sp + 1
                                smp = 'T'
                                if gap == 'T':
                                    gp = gp + 1
                                    gap = 'F'
                            elif int(payload_sizes[j]) > 86:
                                if smp == 'T':
                                    gap = 'T'

                        t = (sp - gp - 1) / tp
                        if tconsecutive == 0:
                            alpha = -999
                        elif tconsecutive == 1 and aconsecutive == 1:
                            alpha = 1
                        else:
                            alpha = aconsecutive / tconsecutive

                        print(t, '\n')
                        print(alpha, '\n')
                        data1.append(str(tp))
                        data1.append(str(sp))
                        data1.append(str(gp))
                        data1.append(str(t))
                        data1.append(str(alpha))

                self.result.append(data1)

        print(self.result)



