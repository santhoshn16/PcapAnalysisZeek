import os
import sys
import time


class GenerateDir:
    def __init__(self, pcap_name):
        self.pcap_name = pcap_name

    def makedir(self):
        try:
            if not os.path.isdir(self.pcap_name):
                os.mkdir('dir_%s' % self.pcap_name)
                os.system('cp %s dir_%s' % (self.pcap_name, self.pcap_name))
                # os.system('cp desc.html dir_%s' % self.pcap_name)
                os.chdir('dir_%s' % self.pcap_name)
                # os.mkdir('Images')
                # os.mkdir('Hist')
        except OSError:
            print('Already executed %s\n' % self.pcap_name)
            print('Re-Executing this %s in 10 sec\n' % self.pcap_name)
            time.sleep(10)
            # option = input('enter \'R\' to re analysis the file\n')
            option = 'r'
            if option == 'R' or option == 'r':
                os.system('rm -r dir_%s' % self.pcap_name)
                os.mkdir('dir_%s' % self.pcap_name)
                os.system('cp %s dir_%s' % (self.pcap_name, self.pcap_name))
                # os.system('cp desc.html dir_%s' % self.pcap_name)
                os.chdir('dir_%s' % self.pcap_name)
                # os.mkdir('Images')
                # os.mkdir('Hist')
            else:
                sys.exit(0)
